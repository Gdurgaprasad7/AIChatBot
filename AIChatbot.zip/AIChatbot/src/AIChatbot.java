import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;
import java.util.regex.*;

/**
 * AI FAQ Chatbot ("NovaBot") - Java, Swing GUI + console mode.
 *
 * NLP pipeline : lowercase -> tokenize -> stop-word removal -> synonym mapping -> stemming
 * ML logic     : TF-IDF vectors + cosine similarity (retrieval-based classifier)
 * Rule-based   : greetings, thanks, goodbye, name memory, help command
 * Trainable    : type   teach: your question => the answer   to train it live
 *
 * Run GUI     : java AIChatbot
 * Run console : java AIChatbot --console
 */
public class AIChatbot {

    // =====================================================================
    //  1. NLP utilities
    // =====================================================================
    static class NLP {
        static final Set<String> STOP = new HashSet<>(Arrays.asList(
            "a", "an", "the", "is", "are", "am", "was", "were", "be", "been", "to", "of", "in", "on",
            "at", "for", "and", "or", "do", "does", "did", "i", "you", "me", "my", "your", "we", "our",
            "it", "its", "this", "that", "can", "could", "would", "will", "shall", "should", "please",
            "tell", "about", "with", "as", "so", "if", "there", "any", "some", "get", "want", "need",
            "know", "like", "hi", "hello", "hey", "what", "how", "which", "who"));

        // word -> canonical word (a tiny hand-made thesaurus)
        static final Map<String, String> SYN = new HashMap<>();
        static {
            String[][] groups = {
                {"price", "cost", "costs", "fee", "fees", "charge", "charges", "pricing", "pay", "expensive", "cheap"},
                {"hour", "hours", "open", "opening", "timing", "timings", "time", "closed", "close"},
                {"order", "buy", "purchase", "purchasing", "checkout"},
                {"refund", "return", "returns", "reimburse", "reimbursement", "moneyback", "money"},
                {"contact", "reach", "call", "phone", "email", "mail", "talk", "support", "helpdesk"},
                {"shipping", "ship", "deliver", "delivery", "dispatch", "courier", "arrive"},
                {"password", "passcode", "forgot", "forgotten", "reset", "login", "signin"},
                {"account", "register", "signup", "profile", "registration"},
                {"warranty", "guarantee", "repair", "defect", "broken", "faulty"},
                {"track", "tracking", "status", "where"},
                {"cancel", "cancellation", "stop"},
                {"payment", "card", "upi", "visa", "mastercard", "wallet", "cod"},
                {"discount", "coupon", "promo", "offer", "sale", "deal", "voucher"},
                {"location", "address", "store", "shop", "office", "located"}
            };
            for (String[] g : groups)
                for (String w : g) SYN.put(w, g[0]);
        }

        static List<String> tokenize(String text) {
            String clean = text.toLowerCase().replaceAll("[^a-z0-9\\s]", " ");
            List<String> out = new ArrayList<>();
            for (String w : clean.split("\\s+")) {
                if (w.isEmpty() || STOP.contains(w)) continue;
                w = SYN.getOrDefault(w, w);
                out.add(stem(w));
            }
            return out;
        }

        /** Light suffix-stripping stemmer (applied to both questions and user input, so it stays consistent). */
        static String stem(String w) {
            if (w.length() > 4 && w.endsWith("ies")) return w.substring(0, w.length() - 3) + "y";
            if (w.length() > 5 && w.endsWith("ing")) return w.substring(0, w.length() - 3);
            if (w.length() > 4 && w.endsWith("ed")) return w.substring(0, w.length() - 2);
            if (w.length() > 3 && w.endsWith("s") && !w.endsWith("ss")) return w.substring(0, w.length() - 1);
            return w;
        }
    }

    // =====================================================================
    //  2. Knowledge base entry
    // =====================================================================
    static class Faq {
        final String question, answer;
        final String trainingText;   // question + alternate phrasings

        Faq(String question, String answer, String... alternates) {
            this.question = question;
            this.answer = answer;
            this.trainingText = question + " " + String.join(" ", alternates);
        }
    }

    // =====================================================================
    //  3. TF-IDF model (the "machine learning" part)
    // =====================================================================
    static class Model {
        private final List<Faq> faqs = new ArrayList<>();
        private final List<Map<String, Double>> vectors = new ArrayList<>();
        private Map<String, Double> idf = new HashMap<>();

        void add(Faq f) { faqs.add(f); }
        int size() { return faqs.size(); }
        List<Faq> getFaqs() { return faqs; }

        /** (Re)train: compute IDF weights and one TF-IDF vector per FAQ. */
        void train() {
            int n = faqs.size();
            Map<String, Integer> df = new HashMap<>();
            List<List<String>> docs = new ArrayList<>();
            for (Faq f : faqs) {
                List<String> toks = NLP.tokenize(f.trainingText);
                docs.add(toks);
                for (String t : new HashSet<>(toks)) df.merge(t, 1, Integer::sum);
            }
            idf = new HashMap<>();
            for (Map.Entry<String, Integer> e : df.entrySet())
                idf.put(e.getKey(), Math.log((n + 1.0) / (e.getValue() + 1.0)) + 1.0);

            vectors.clear();
            for (List<String> d : docs) vectors.add(vectorize(d));
        }

        private Map<String, Double> vectorize(List<String> tokens) {
            Map<String, Double> v = new HashMap<>();
            for (String t : tokens) {
                Double w = idf.get(t);
                if (w != null) v.merge(t, w, Double::sum);   // tf * idf
            }
            double norm = 0;
            for (double x : v.values()) norm += x * x;
            norm = Math.sqrt(norm);
            if (norm > 0) for (Map.Entry<String, Double> e : v.entrySet()) e.setValue(e.getValue() / norm);
            return v;
        }

        private static double cosine(Map<String, Double> a, Map<String, Double> b) {
            double dot = 0;
            for (Map.Entry<String, Double> e : a.entrySet()) {
                Double o = b.get(e.getKey());
                if (o != null) dot += e.getValue() * o;
            }
            return dot; // vectors are already unit length
        }

        /** Returns {index, score} of the best matching FAQ. */
        double[] bestMatch(String input) {
            Map<String, Double> q = vectorize(NLP.tokenize(input));
            double best = 0;
            int idx = -1;
            for (int i = 0; i < vectors.size(); i++) {
                double s = cosine(q, vectors.get(i));
                if (s > best) { best = s; idx = i; }
            }
            return new double[]{idx, best};
        }
    }

    // =====================================================================
    //  4. The bot: rules + model
    // =====================================================================
    static class Bot {
        static final double CONFIDENT = 0.35, MAYBE = 0.18;
        private final Model model = new Model();
        private final Random rnd = new Random();
        private String userName = null;
        private static final Pattern TEACH = Pattern.compile("(?i)^teach\\s*:\\s*(.+?)\\s*=>\\s*(.+)$");
        private static final Pattern NAME = Pattern.compile("(?i)\\b(?:my name is|i am called|call me)\\s+([a-z]+)");

        Bot() {
            loadFaqs();
            model.train();
        }

        private void loadFaqs() {
            model.add(new Faq("What are your opening hours?",
                "We're open Monday to Saturday, 9 AM - 8 PM. Our online store and this chat are available 24/7.",
                "when do you open", "what time do you close", "business timings", "are you open on sunday"));
            model.add(new Faq("How can I contact customer support?",
                "You can reach support at support@technova.example, call 1800-123-456 (toll-free), or keep chatting with me!",
                "phone number", "email address", "talk to a human agent", "customer care number"));
            model.add(new Faq("How do I place an order?",
                "Browse the catalog, add items to your cart, click Checkout, enter your address and pay. You'll get a confirmation email instantly.",
                "how to buy a product", "steps to purchase", "ordering process"));
            model.add(new Faq("How long does shipping take?",
                "Standard delivery takes 3-5 business days. Express delivery (extra fee) arrives in 1-2 business days.",
                "delivery time", "when will my order arrive", "how many days for delivery", "shipping duration"));
            model.add(new Faq("How much does shipping cost?",
                "Shipping is free on orders above Rs. 999. Otherwise a flat fee of Rs. 49 applies.",
                "delivery charges", "is shipping free", "shipping fee", "courier cost"));
            model.add(new Faq("How do I track my order?",
                "Open 'My Orders' in your account and click 'Track'. A tracking link is also emailed once your order ships.",
                "where is my order", "order status", "tracking number", "track my package"));
            model.add(new Faq("What is your return and refund policy?",
                "You can return items within 30 days in original condition. Refunds are processed to your original payment method within 5-7 business days.",
                "can I return a product", "money back guarantee", "how do I get a refund", "return window"));
            model.add(new Faq("How do I cancel my order?",
                "Go to 'My Orders' and click 'Cancel' before the order ships. After shipping, please use the return process.",
                "cancel purchase", "I want to cancel", "stop my order"));
            model.add(new Faq("What payment methods do you accept?",
                "We accept credit/debit cards, UPI, net banking, popular wallets and Cash on Delivery (orders up to Rs. 5,000).",
                "can I pay with UPI", "do you accept credit card", "cash on delivery available", "how can I pay"));
            model.add(new Faq("How do I reset my password?",
                "Click 'Forgot password' on the login page, enter your email, and follow the reset link we send you (valid for 30 minutes).",
                "I forgot my password", "can't log in", "change password", "unable to sign in"));
            model.add(new Faq("How do I create an account?",
                "Click 'Sign up' at the top right, enter your name, email and a password, then verify your email address.",
                "register on the website", "sign up process", "make a new profile"));
            model.add(new Faq("Do you offer any discounts or coupons?",
                "Yes! Subscribe to our newsletter for a 10% welcome coupon, and check the 'Offers' page for ongoing sales.",
                "promo code", "any sale going on", "student discount", "voucher"));
            model.add(new Faq("What is the warranty on your products?",
                "All electronics carry a 1-year manufacturer warranty. Extended 2-year protection can be added at checkout.",
                "product guarantee", "my device is faulty", "repair policy", "broken item"));
            model.add(new Faq("Where is your store located?",
                "Our flagship store is at 12 Tech Park Road, Bengaluru. Find more locations on the 'Stores' page.",
                "store address", "where is your shop", "office location", "visit in person"));
        }

        String greeting() {
            return "Hi! I'm NovaBot, your virtual assistant. Ask me about orders, shipping, returns, payments or "
                 + "your account. Type 'help' to see topics.";
        }

        String reply(String raw) {
            String input = raw == null ? "" : raw.trim();
            if (input.isEmpty()) return "Please type a question and I'll do my best to help.";
            String lower = input.toLowerCase();

            // ---- Training command
            Matcher t = TEACH.matcher(input);
            if (t.matches()) {
                model.add(new Faq(t.group(1).trim(), t.group(2).trim()));
                model.train();
                return "Thanks! I've learned a new answer and retrained myself. I now know " + model.size() + " topics.";
            }

            // ---- Rule-based small talk
            Matcher nm = NAME.matcher(input);
            if (nm.find()) {
                String n = nm.group(1);
                userName = Character.toUpperCase(n.charAt(0)) + n.substring(1).toLowerCase();
                return "Nice to meet you, " + userName + "! How can I help you today?";
            }
            if (matches(lower, "^(hi|hello|hey|hola|good (morning|afternoon|evening))\\b.*"))
                return pick("Hello", "Hi there", "Hey") + (userName != null ? ", " + userName : "") + "! How can I help you?";
            if (matches(lower, ".*\\b(thanks|thank you|thx|cheers)\\b.*"))
                return pick("You're welcome!", "Happy to help!", "Anytime!") + " Anything else?";
            if (matches(lower, ".*\\b(bye|goodbye|see you|exit|quit)\\b.*"))
                return "Goodbye" + (userName != null ? ", " + userName : "") + "! Have a great day.";
            if (matches(lower, ".*\\b(how are you|how r u)\\b.*"))
                return "I'm just code, but I'm running great! What can I do for you?";
            if (matches(lower, ".*\\b(who are you|your name|what are you)\\b.*"))
                return "I'm NovaBot, a Java chatbot that uses NLP and TF-IDF similarity to answer FAQs.";
            if (matches(lower, "^(help|topics|menu)\\??$"))
                return topics();

            // ---- ML retrieval
            double[] m = model.bestMatch(input);
            int idx = (int) m[0];
            double score = m[1];

            if (idx >= 0 && score >= Bot.CONFIDENT) return model.getFaqs().get(idx).answer;
            if (idx >= 0 && score >= Bot.MAYBE)
                return "I am not completely sure, but did you mean: \"" + model.getFaqs().get(idx).question
                     + "\"\n" + model.getFaqs().get(idx).answer;

            return "Sorry, I don't know that one yet. Type 'help' to see what I can answer, or teach me with:\n"
                 + "teach: your question => the answer";
        }

        private String topics() {
            StringBuilder sb = new StringBuilder("Here are things you can ask me:\n");
            for (Faq f : model.getFaqs()) sb.append(" - ").append(f.question).append("\n");
            sb.append("You can also teach me: teach: question => answer");
            return sb.toString().trim();
        }

        private boolean matches(String s, String regex) { return s.matches(regex); }
        private String pick(String... opts) { return opts[rnd.nextInt(opts.length)]; }
    }

    // =====================================================================
    //  5. Swing GUI
    // =====================================================================
    static class ChatWindow extends JFrame {
        private final Bot bot = new Bot();
        private final JTextPane chat = new JTextPane();
        private final JTextField field = new JTextField();
        private final JButton send = new JButton("Send");
        private final JLabel status = new JLabel(" ");

        ChatWindow() {
            super("NovaBot - AI FAQ Assistant");
            setDefaultCloseOperation(EXIT_ON_CLOSE);
            setSize(520, 640);
            setLocationRelativeTo(null);

            JLabel header = new JLabel("  NovaBot  |  NLP + TF-IDF chatbot");
            header.setOpaque(true);
            header.setBackground(new Color(0x1565C0));
            header.setForeground(Color.WHITE);
            header.setFont(new Font("SansSerif", Font.BOLD, 16));
            header.setBorder(BorderFactory.createEmptyBorder(12, 8, 12, 8));

            chat.setEditable(false);
            chat.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
            JScrollPane scroll = new JScrollPane(chat);

            field.setFont(new Font("SansSerif", Font.PLAIN, 14));
            field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.LIGHT_GRAY), BorderFactory.createEmptyBorder(6, 8, 6, 8)));
            send.setFocusPainted(false);

            JPanel inputRow = new JPanel(new BorderLayout(6, 0));
            inputRow.add(field, BorderLayout.CENTER);
            inputRow.add(send, BorderLayout.EAST);

            JPanel bottom = new JPanel(new BorderLayout(0, 4));
            bottom.setBorder(BorderFactory.createEmptyBorder(6, 8, 8, 8));
            bottom.add(status, BorderLayout.NORTH);
            bottom.add(inputRow, BorderLayout.CENTER);

            setLayout(new BorderLayout());
            add(header, BorderLayout.NORTH);
            add(scroll, BorderLayout.CENTER);
            add(bottom, BorderLayout.SOUTH);

            ActionListener sendAction = e -> onSend();
            send.addActionListener(sendAction);
            field.addActionListener(sendAction);

            append(bot.greeting(), false);
            field.requestFocusInWindow();
        }

        private void onSend() {
            String text = field.getText().trim();
            if (text.isEmpty()) return;
            field.setText("");
            append(text, true);

            // simulate a short "typing" delay for a real-time feel
            field.setEnabled(false);
            send.setEnabled(false);
            status.setText("  NovaBot is typing...");
            javax.swing.Timer timer = new javax.swing.Timer(450, e -> {
                append(bot.reply(text), false);
                status.setText(" ");
                field.setEnabled(true);
                send.setEnabled(true);
                field.requestFocusInWindow();
            });
            timer.setRepeats(false);
            timer.start();
        }

        private void append(String text, boolean user) {
            StyledDocument doc = chat.getStyledDocument();
            SimpleAttributeSet a = new SimpleAttributeSet();
            StyleConstants.setAlignment(a, user ? StyleConstants.ALIGN_RIGHT : StyleConstants.ALIGN_LEFT);
            StyleConstants.setForeground(a, user ? new Color(0x0D47A1) : new Color(0x1B5E20));
            StyleConstants.setFontFamily(a, "SansSerif");
            StyleConstants.setFontSize(a, 14);
            String line = (user ? "You: " : "NovaBot: ") + text + "\n\n";
            try {
                int start = doc.getLength();
                doc.insertString(start, line, a);
                doc.setParagraphAttributes(start, line.length(), a, false);
            } catch (BadLocationException ignored) { }
            chat.setCaretPosition(doc.getLength());
        }
    }

    // =====================================================================
    //  6. Entry point
    // =====================================================================
    public static void main(String[] args) {
        boolean console = Arrays.asList(args).contains("--console") || GraphicsEnvironment.isHeadless();
        if (console) {
            runConsole();
        } else {
            SwingUtilities.invokeLater(() -> new ChatWindow().setVisible(true));
        }
    }

    static void runConsole() {
        Bot bot = new Bot();
        Scanner sc = new Scanner(System.in);
        System.out.println("NovaBot: " + bot.greeting());
        System.out.println("(type 'exit' to quit)\n");
        while (true) {
            System.out.print("You: ");
            if (!sc.hasNextLine()) break;
            String line = sc.nextLine();
            String r = bot.reply(line);
            System.out.println("NovaBot: " + r + "\n");
            if (line.trim().toLowerCase().matches(".*\\b(bye|exit|quit)\\b.*")) break;
        }
    }
}
