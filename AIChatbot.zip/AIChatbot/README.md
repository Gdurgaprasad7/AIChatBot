# AI Chatbot - NovaBot (Eclipse project)

Java FAQ chatbot with a Swing GUI.
- NLP: tokenization, stop-word removal, synonym mapping, stemming
- ML: TF-IDF vectors + cosine similarity
- Rule-based: greetings, thanks, goodbye, name memory, help
- Trainable at runtime:  teach: your question => the answer

## Import into Eclipse
File > Import... > General > Existing Projects into Workspace > select this folder (or the .zip) > Finish

## Run
Right-click src/AIChatbot.java > Run As > Java Application  (opens the chat window)

Text mode: Run > Run Configurations > Arguments > Program arguments: --console

Requires JDK 11 or newer.
